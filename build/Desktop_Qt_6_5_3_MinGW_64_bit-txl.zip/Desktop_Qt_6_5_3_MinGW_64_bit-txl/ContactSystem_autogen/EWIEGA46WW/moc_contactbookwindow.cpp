/****************************************************************************
** Meta object code from reading C++ file 'contactbookwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../contactbookwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'contactbookwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSContactBookWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSContactBookWindowENDCLASS = QtMocHelpers::stringData(
    "ContactBookWindow",
    "onContactButtonClicked",
    "",
    "onBackButtonClicked",
    "onAddContactButtonClicked",
    "onManageButtonClicked",
    "onSearchButtonClicked",
    "onResetButtonClicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSContactBookWindowENDCLASS_t {
    uint offsetsAndSizes[16];
    char stringdata0[18];
    char stringdata1[23];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[26];
    char stringdata5[22];
    char stringdata6[22];
    char stringdata7[21];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSContactBookWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSContactBookWindowENDCLASS_t qt_meta_stringdata_CLASSContactBookWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 17),  // "ContactBookWindow"
        QT_MOC_LITERAL(18, 22),  // "onContactButtonClicked"
        QT_MOC_LITERAL(41, 0),  // ""
        QT_MOC_LITERAL(42, 19),  // "onBackButtonClicked"
        QT_MOC_LITERAL(62, 25),  // "onAddContactButtonClicked"
        QT_MOC_LITERAL(88, 21),  // "onManageButtonClicked"
        QT_MOC_LITERAL(110, 21),  // "onSearchButtonClicked"
        QT_MOC_LITERAL(132, 20)   // "onResetButtonClicked"
    },
    "ContactBookWindow",
    "onContactButtonClicked",
    "",
    "onBackButtonClicked",
    "onAddContactButtonClicked",
    "onManageButtonClicked",
    "onSearchButtonClicked",
    "onResetButtonClicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSContactBookWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   50,    2, 0x08,    1 /* Private */,
       3,    0,   51,    2, 0x08,    2 /* Private */,
       4,    0,   52,    2, 0x08,    3 /* Private */,
       5,    0,   53,    2, 0x08,    4 /* Private */,
       6,    0,   54,    2, 0x08,    5 /* Private */,
       7,    0,   55,    2, 0x08,    6 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ContactBookWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSContactBookWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSContactBookWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSContactBookWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ContactBookWindow, std::true_type>,
        // method 'onContactButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onBackButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onAddContactButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onManageButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSearchButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onResetButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ContactBookWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ContactBookWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onContactButtonClicked(); break;
        case 1: _t->onBackButtonClicked(); break;
        case 2: _t->onAddContactButtonClicked(); break;
        case 3: _t->onManageButtonClicked(); break;
        case 4: _t->onSearchButtonClicked(); break;
        case 5: _t->onResetButtonClicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *ContactBookWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ContactBookWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSContactBookWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int ContactBookWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
